from django.db import models

# Create your models here.
class Book(models.Model):
    title=models.CharField(max_length=100,blank=True)
    author=models.CharField(max_length=100,blank=True)
    Publisher=models.CharField(max_length=100,blank=True)

    def __str__(self) -> str:
        return self.title